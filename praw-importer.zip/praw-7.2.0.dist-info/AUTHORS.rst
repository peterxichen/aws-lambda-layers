Maintainers
===========

- Bryce Boe <bbzbryce@gmail.com> `@bboe <https://github.com/bboe>`_
- Joe RH <jarhill0@gmail.com> `@jarhill0 <https://github.com/jarhill0>`_
- Joel Payne <lilspazjoekp@gmail.com> `@LilSpazJoekp <https://github.com/LilSpazJoekp>`_


Documentation Contributors
==========================

- Dale Cudmore <dalecudmore@gmail.com> `@DCuddies <https://github.com/DCuddies>`_
- Zhifu Ge <zhifu@me.com> `@zhifuge <https://github.com/zhifuge>`_
- diceroll123 `@diceroll123 <https://github.com/diceroll123>`_
- Watchful1 `@Watchful1 <https://github.com/Watchful1>`_
- theonefoster `@theonefoster <https://github.com/theonefoster>`_
- Eric Woolard `@ericwoolard <https://github.com/ericwoolard>`_
- Marc `@PerhapsSomeone <https://github.com/PerhapsSomeone>`_
- Richard Hoekstra `@RichardHoekstra <https://github.com/RichardHoekstra>`_
- Pim Tholhuijsen `@mandjevant <https://github.com/mandjevant>`_
- Martin Michlmayr `@tbm <https://github.com/tbm>`_
- jac0b-w `@jac0b-w <https://github.com/jac0b-w>`_
- Kenneth Yang `@kennethy <https://github.com/kennethy>`_
- Tarak Oueriache <Igosad@protonmail.com> `@igosad <https://github.com/igosad>`_
- xCROv `@xCROv <https://github.com/xCROv>`_

<!-- - Add "Name <email (optional)> and github profile link" above this line. -->


Logo Creator
============

- kungming2 `@kungming2 <https://github.com/kungming2>`_


Source Contributors
===================

- Ethan Dalool <edalool@yahoo.com> `@voussoir <https://github.com/voussoir>`_
- William McKinnerney <me@williammck.net> `@williammck <https://github.com/williammck>`_
- Katharine Jarmul <katharine@kjamistan.com> `@kjam <https://github.com/kjam>`_
- nmtake `@nmtake <https://github.com/nmtake>`_
- Levi Roth <levimroth@gmail.com> `@leviroth <https://github.com/leviroth>`_
- Keith Diedrick <kediedrick@gmail.com> `@darthkedrik <https://github.com/darthkedrik>`_
- elnuno `@elnuno <https://github.com/elnuno>`_
- Robbie Gibson `@rkgibson2 <https://github.com/rkgibson2>`_
- Mike Wohlrab `@D0cR3d <https://github.com/D0cR3d>`_
- Matthew Lee `@kwwxis <https://github.com/kwwxis>`_
- guaneec `@guaneec <https://github.com/guaneec>`_
- Jason Woodrich `@jwoodrich <https://github.com/jwoodrich>`_
- Andrew Arnold `@asquared31415 <https://github.com/asquared31415>`_
- bakonydraco `@bakonydraco <https://github.com/bakonydraco>`_
- salehio `@salehio <https://github.com/salehio>`_
- Amanda O'Neal <amanda.oneal.dev@gmail.com> `@amandaoneal <https://github.com/amandaoneal>`_
- Gourari Oussama <gourari.ouss@gmail.com> `@O-Gourari <https://github.com/O-Gourari>`_
- Declan Hoare <declanhoare@exemail.com.au> `@NetwideRogue <https://github.com/NetwideRogue>`_
- Elaina Martineau `@CrackedP0t <https://github.com/CrackedP0t>`_
- Rob Curtis <BourbonInExile@gmail.com> `@waab76 <https://github.com/waab76>`_
- Pyprohly <pyprohly@outlook.com> `@Pyprohly <https://github.com/Pyprohly>`_
- Timendum `@timendum <https://github.com/timendum>`_
- vaclav-2012 `@vaclav-2012 <https://github.com/vaclav-2012>`_
- Jon Meager `@H4CKY54CK <https://github.com/H4CKY54CK>`_
- kungming2 `@kungming2 <https://github.com/kungming2>`_
- Jack Steel `@jackodsteel <https://github.com/jackodsteel>`_
- David Mirch `@fwump38 <https://github.com/fwump38>`_
- PythonCoderAS `@PythonCoderAS <https://github.com/PythonCoderAS>`_
- Michael Cetrulo <contact@michael-cetrulo.com> `@git2samus <https://github.com/git2samus>`_
- George Schizas `@gschizas <https://github.com/gschizas>`_
- Todd Roberts `@toddrob99 <https://github.com/toddrob99>`_
- MaybeNetwork `@MaybeNetwork <https://github.com/MaybeNetwork>`_
- Nick Kelly `@nickatnight <https://github.com/nickatnight>`_
- Yash Chhabria `@Cyatos <https://github.com/Cyatos>`_
- Justin Krejcha <justin@justinkrejcha.com> `@jkrejcha <https://github.com/jkrejcha>`_

<!-- - Add "Name <email (optional)> and github profile link" above this line. -->
